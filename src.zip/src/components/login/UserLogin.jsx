import { useState } from "react";
import InputField from "./InputField";

const UserLogin = () => {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();

    // TODO:
    // Connect to customer authentication API.
    // Example:
    // loginUser({ userId, password, rememberMe });
  };

  return (
    <form className="login-form" onSubmit={handleSubmit}>

      <InputField
        id="userId"
        label="User ID"
        placeholder="Enter your User ID"
        // icon=""         a person icon can be shown here for username
        value={userId}
        onChange={(e) => setUserId(e.target.value)}
      />

      <div className="form-field">

        <div className="password-label-row">

          <label htmlFor="password">
            Password
          </label>

          <button
            type="button"
            className="forgot-button"
            onClick={() => {
              // TODO: Forgot password flow
            }}
          >
            Forgot?
          </button>

        </div>

        <div className="input-wrapper">

          <span className="input-icon">
            {/* a lock icon can be shown here for pwd */}
          </span>

          <input
            id="password"
            type={showPassword ? "text" : "password"}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button
            type="button"
            className="password-toggle"
            onClick={() => setShowPassword(!showPassword)}
            aria-label="Toggle password visibility"
          >
            {showPassword ? "Hide" : "Show"}
          </button>

        </div>

      </div>

      <label className="remember-me">

        <input
          type="checkbox"
          checked={rememberMe}
          onChange={(e) => setRememberMe(e.target.checked)}
        />

        <span>
          Remember me
        </span>

      </label>

      <button
        type="submit"
        className="login-submit-button"
      >
        <span>Sign In</span>
        <span className="submit-arrow">→</span>
      </button>

    </form>
  );
};

export default UserLogin;
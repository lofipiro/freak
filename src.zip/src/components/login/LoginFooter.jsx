const LoginFooter = () => {
  return (
    <div className="login-footer">

      <p>
        Need help?{" "}
        <button type="button">
          Contact Support
        </button>
      </p>

    </div>
  );
};

export default LoginFooter;
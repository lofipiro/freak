import { useState } from "react";

import LoginHeader from "./LoginHeader";
import LoginCard from "./LoginCard";
import LoginTypeSelector from "./LoginTypeSelector";
import UserLogin from "./UserLogin";
import EnterpriseLogin from "./EnterpriseLogin";
import LoginFooter from "./LoginFooter";

import "../styles/login.css";

const LoginPage = () => {
  const [loginType, setLoginType] = useState("user");

  return (
    <div className="login-page">

      <LoginHeader />

      <main className="login-main">

        <LoginCard>

          <div className="login-heading">
            <h1>Secure Login</h1>

            <p>
              Please authenticate to continue.
            </p>
          </div>

          <LoginTypeSelector
            loginType={loginType}
            setLoginType={setLoginType}
          />

          {loginType === "user" ? (
            <UserLogin />
          ) : (
            <EnterpriseLogin />
          )}

          <LoginFooter />

        </LoginCard>

      </main>

    </div>
  );
};

export default LoginPage;
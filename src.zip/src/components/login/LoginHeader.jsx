const LoginHeader = () => {
  return (
    <header className="login-header">

      <div className="brand">

        {/* =====================================================
            CHANGE SCB LOGO HERE
            Replace the src with the actual SCB logo asset.
            Example:
            src="/assets/scb-logo.svg"
            ===================================================== */}
        <img
          src="/assets/REPLACE_WITH_SCB_LOGO.svg"
          alt="SCB Logo"
          className="brand-logo"
        />

        <span className="brand-name">
          SCB Loan Origination
        </span>

      </div>

    </header>
  );
};

export default LoginHeader;
const LoginCard = ({ children }) => {
  return (
    <section className="login-card">
      {children}
    </section>
  );
};

export default LoginCard;
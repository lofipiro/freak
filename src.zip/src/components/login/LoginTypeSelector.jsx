const LoginTypeSelector = ({ loginType, setLoginType }) => {
  return (
    <div className="login-type-selector">

      <button
        type="button"
        className={`login-type-button ${
          loginType === "user" ? "active" : ""
        }`}
        onClick={() => setLoginType("user")}
      >
        Customer Login
      </button>

      <button
        type="button"
        className={`login-type-button ${
          loginType === "enterprise" ? "active" : ""
        }`}
        onClick={() => setLoginType("enterprise")}
      >
        Enterprise Login
      </button>

    </div>
  );
};

export default LoginTypeSelector;
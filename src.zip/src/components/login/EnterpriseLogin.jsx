import { useState } from "react";
import InputField from "./InputField";

const EnterpriseLogin = () => {
  const [employeeId, setEmployeeId] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();

    // TODO:
    // Connect to enterprise authentication API.
    //
    // Backend should determine:
    // OPS_MAKER
    // OPS_CHECKER
  };

  return (
    <form className="login-form" onSubmit={handleSubmit}>

      <InputField
        id="employeeId"
        label="Employee ID"
        placeholder="Enter your Employee ID"
        // icon=""         a badge icon can be shown here for username
        value={employeeId}
        onChange={(e) => setEmployeeId(e.target.value)}
      />

      <div className="form-field">

        <div className="password-label-row">

          <label htmlFor="enterprisePassword">
            Password
          </label>

          <button
            type="button"
            className="forgot-button"
          >
            Forgot?
          </button>

        </div>

        <div className="input-wrapper">

          <span className="input-icon">
            {/* a lock icon can be shown here for pwd */}
          </span>

          <input
            id="enterprisePassword"
            type={showPassword ? "text" : "password"}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button
            type="button"
            className="password-toggle"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? "Hide" : "Show"}
          </button>

        </div>

      </div>

      <label className="remember-me">

        <input
          type="checkbox"
          checked={rememberMe}
          onChange={(e) => setRememberMe(e.target.checked)}
        />

        <span>
          Remember me
        </span>

      </label>

      <button
        type="submit"
        className="login-submit-button"
      >
        <span>Sign In</span>
        <span className="submit-arrow">→</span>
      </button>

    </form>
  );
};

export default EnterpriseLogin;
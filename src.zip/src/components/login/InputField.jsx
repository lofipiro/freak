const InputField = ({
  id,
  label,
  placeholder,
  type = "text",
  icon,
  value,
  onChange,
}) => {
  return (
    <div className="form-field">

      <label htmlFor={id}>
        {label}
      </label>

      <div className="input-wrapper">

        <span className="input-icon">
          {icon}
        </span>

        <input
          id={id}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          required
        />

      </div>

    </div>
  );
};

export default InputField;